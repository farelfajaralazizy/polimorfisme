/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfisme;

/**
 *
 * @author Tedii
 */
public class Polimorfisme {

    //    float luas (float r) {
//        return (float) (Math.PI*r*r);
//    }
//        
//    double luas (double d) {
//        return (double) (1/4 * Math.PI * d);
//    
//    }

    float luas(){
        System.out.println("Menghitung luas bangun datar ...");
        return 0;
    }
    float keliling (){
        System.out.println("MEnghitung keliling bangun datar ...");
        return 0;
    }
}